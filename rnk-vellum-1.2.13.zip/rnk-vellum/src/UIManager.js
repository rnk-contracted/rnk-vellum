import { CONTAINER_ID_FLAG, MODULE_ID } from './VellumDataModel.js';

/**
 * RNK™ Vellum — UIManager.js
 * Singleton window registry. Prevents duplicate sub-windows and routes
 * open/close/focus for ContainerWindow and NotepadWindow.
 * © 2026 RNK Enterprise. All rights reserved. See LICENSE.
 */

const _registry = new Map();

export class UIManager {

  /**
   * Open (or focus) a ContainerWindow for the given item.
   * @param {Item}  item
   * @param {Actor} actor
   */
  static async openContainer(item, actor) {
    const key = `container:${item.id}`;

    if (_registry.has(key)) {
      const existing = _registry.get(key);
      existing.bringToFront?.();
      return;
    }

    const { ContainerWindow } = await import('./ContainerWindow.js');
    const win = new ContainerWindow(item, actor, key);
    _registry.set(key, win);
    win.render(true);
  }

  /**
   * Open (or focus) a NotepadWindow for the given item.
   * @param {Item}  item
   * @param {Actor} actor
   */
  static async openNotepad(item, actor) {
    const key = `notepad:${item.id}`;

    if (_registry.has(key)) {
      const existing = _registry.get(key);
      existing.bringToFront?.();
      return;
    }

    const { NotepadWindow } = await import('./NotepadWindow.js');
    const win = new NotepadWindow(item, actor, key);
    _registry.set(key, win);
    win.render(true);
  }

  /**
   * Remove a window from the registry (called on close).
   * @param {string} key
   */
  static deregister(key) {
    _registry.delete(key);
  }

  /**
   * Re-render an open container window for a given item id.
   * @param {string} itemId
   */
  static refreshContainer(itemId) {
    const win = _registry.get(`container:${itemId}`);
    if (win?.rendered) win.render();
  }

  /**
   * Refresh container windows affected by an item update.
   * @param {Item} item
   * @param {string|null} previousContainerId
   */
  static refreshForItem(item, previousContainerId = null) {
    this.refreshContainer(item.id);

    const currentContainerId = item.getFlag(MODULE_ID, CONTAINER_ID_FLAG) ?? null;
    if (currentContainerId) this.refreshContainer(currentContainerId);
    if (previousContainerId && previousContainerId !== currentContainerId) {
      this.refreshContainer(previousContainerId);
    }
  }

  /**
   * Close all open vellum sub-windows (e.g. when actor sheet closes).
   */
  static closeAll() {
    for (const [key, win] of _registry.entries()) {
      win.close({ force: true });
      _registry.delete(key);
    }
  }
}
